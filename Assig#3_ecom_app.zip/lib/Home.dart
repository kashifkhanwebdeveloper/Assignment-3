import 'package:flutter/material.dart';

import 'List.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff1ca335),
        centerTitle: true,
        title: Text("Ecom App UI "),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // SizedBox(
            //   height: 30,
            // ),

            TextField(),

            item(),
            item2(),
            item3(),
            item4(),
            item(),
            item(),
            item(),
            item(),
            item(),

            // ListTile(
            //   leading: CircleAvatar(
            //     backgroundImage: AssetImage('asset/bg.jpeg'),
            //     radius: 30,
            //   ),
            //   title: Text("Iphone"),
            //   subtitle: Text("300"),
            // ),
            // SizedBox(
            //   height: 30,
            // ),
            // Container(
            //   child: Center(child: Text("Box Decoration")),
            //   height: 200,
            //   width: 200,
            //   decoration: BoxDecoration(color: Colors.blue, borderRadius: BorderRadius.circular(20)),
            // ),
            // SizedBox(
            //   height: 30,
            // ),
            // Container(
            //   child: Center(child: Text("Box Decoration")),
            //   height: 200,
            //   width: 200,
            //   decoration: BoxDecoration(color: Colors.blue, borderRadius: BorderRadius.circular(20)),
            // ),
            // SizedBox(
            //   height: 30,
            // ),
            // Container(
            //   child: Center(child: Text("Box Decoration")),
            //   height: 200,
            //   width: 200,
            //   decoration: BoxDecoration(color: Colors.blue, borderRadius: BorderRadius.circular(20)),
            // ),
            // ElevatedButton(
            //     onPressed: () {
            //       Navigator.push(context, MaterialPageRoute(builder: (context) => List()));
            //     },
            //     child: Text("Button")),
          ],
        ),
      ),
    );
  }
}

Widget item() {
  return ListTile(
    leading: CircleAvatar(
      backgroundImage: AssetImage('images/phone.jpg'),
      radius: 40,
    ),
    title: Text("Iphone"),
    subtitle: Text("23 Reviews"),
    trailing: Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Text("\$10"),
      ],
    ),
  );
  SizedBox(
    height: 30,
  );
}

Widget item2() {
  return ListTile(
    leading: CircleAvatar(
      backgroundImage: AssetImage('images/lptop.jpeg'),
      radius: 40,
    ),
    title: Text("Macbook Pro"),
    subtitle: Text("23 Reviews"),
    trailing: Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Text("\$20"),
      ],
    ),
  );
  SizedBox(
    height: 30,
  );
}

Widget item3() {
  return ListTile(
    leading: CircleAvatar(
      backgroundImage: AssetImage('images/lptop.jpeg'),
      radius: 40,
    ),
    title: Text("Macbook Air"),
    subtitle: Text("23 Reviews"),
    trailing: Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Text("\$20"),
      ],
    ),
  );
  SizedBox(
    height: 30,
  );
}

Widget item4() {
  return ListTile(
    leading: CircleAvatar(
      backgroundImage: AssetImage('images/gaming.jpg'),
      radius: 40,
    ),
    title: Text("Gaming PC"),
    subtitle: Text("23 Reviews"),
    trailing: Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Text("\$20"),
      ],
    ),
  );
  SizedBox(
    height: 30,
  );
}
