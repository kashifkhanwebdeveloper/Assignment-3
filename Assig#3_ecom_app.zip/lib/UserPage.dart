import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  @override
  _State createState() => _State();
}

class _State extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Ecom APP UI'),
        ),
        // backgroundImage: AssetImage('images/User.png'),
        body: Padding(
            padding: EdgeInsets.all(5),
            child: Column(
              children: <Widget>[
                Image.asset(
                  'images/User.png',
                  height: 100,
                  width: 100,
                ),
                Text("ACCOUNT INFORMATION"),
                SizedBox(
                  height: 30,
                  width: 10,
                ),
                TextField(
                  decoration: InputDecoration(
                    //  border: OutlineInputBorder(),
                    labelText: 'Full Name',
                  ),
                ),
                TextField(
                  decoration: InputDecoration(
                    //  border: OutlineInputBorder(),
                    labelText: 'Email',
                  ),
                ),
                TextField(
                  decoration: InputDecoration(
                    //  border: OutlineInputBorder(),
                    labelText: 'Phone',
                  ),
                ),
                TextField(
                  decoration: InputDecoration(
                    //  border: OutlineInputBorder(),
                    labelText: 'Address',
                  ),
                ),
                TextField(
                  decoration: InputDecoration(
                    //  border: OutlineInputBorder(),
                    labelText: 'Gender',
                  ),
                ),
                TextField(
                  decoration: InputDecoration(
                    //  border: OutlineInputBorder(),
                    labelText: 'Date Of Birth',
                  ),
                ),
              ],
            )));
  }
}
